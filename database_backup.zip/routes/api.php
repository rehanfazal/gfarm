<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('mobilesignup', 'Api\MobileController@mobileSignUp');
Route::post('mobilelogin', 'Api\MobileController@mobilelogin');
Route::post('mobilelogout', 'Api\MobileController@mobilelogout');
Route::post('mobileusers', 'Api\MobileController@mobileUsers');
Route::post('useraccountactive', 'Api\MobileController@userAccountActive');
Route::post('useraccountunactive', 'Api\MobileController@userAccountUnActive');
Route::post('emailverify', 'Api\MobileController@otpConfirmViaEmail');

/* Change/Reset Password */
Route::post('forgotpassword', 'Api\MobileController@forgetPassword');
Route::post('forgotpasswordotp', 'Api\MobileController@matchforgotpasswordCode');
Route::post('newpassword', 'Api\MobileController@newPassword');

/* User Ratings */
Route::post('adduserrating','Api\RatingController@addUserRating');
Route::post('checkusername','Api\MobileController@checkUsername');
Route::post('getuserinfo','Api\MobileController@getUserData');
Route::post('getsubaccounts','Api\MobileController@getSubUserAccounts');
Route::post('addsubaccounts','Api\MobileController@addSubAccounts');
Route::post('getcountry','Api\MobileController@getCountry');
Route::post('getcountryname','Api\MobileController@getCountryName');
Route::post('updateuserinfo','Api\MobileController@getUserDataUpdated');
Route::post('getuseraddress','Api\GroomController@getAddress');
Route::post('useraddress','Api\GroomController@addAddress');
Route::post('deleteuseraddress','Api\GroomController@deleteAddress');
Route::post('getusercreditcard','Api\GroomController@getCreditCard');
Route::post('usercreditcard','Api\GroomController@addCreditCard');
Route::post('deleteusercreditcard','Api\GroomController@deleteCreditCard');

/* Categories Routes */
Route::post('getmainservices','Api\CategoryController@getAllServices');
Route::post('getmainservicequestion','Api\CategoryController@getMainServiceQuestions');
Route::post('getallquestionoption','Api\CategoryController@getAllQuestionOptions');
Route::post('getmainservicequestionoption','Api\CategoryController@getMainServiceQuestionOptions');
Route::post('getquestionoptionactivities','Api\CategoryController@getQuestionOptionActivity');
Route::post('getquestionoptionclassification','Api\CategoryController@getQuestionOptionClassification');

/* Jobs Routes */
Route::post('addjobs','Api\JobsController@addJobs');
Route::post('getjobslist','Api\JobsController@getJobsList');
Route::post('getspjobslist','Api\JobsController@getSPJobsList');

Route::post('acceptspforjob','Api\JobsController@acceptSPJobRequest');
Route::post('changejobstatus','Api\JobsController@changeJobStatus');
Route::post('spgetqrcode','Api\JobsController@spGetQRCode');
Route::post('usergetqrcode','Api\JobsController@userGetQRCode');
Route::post('usercheckqrcodejobstart','Api\JobsController@userCheckQrCodeJobStart');
Route::post('spcheckqrcodejobstart','Api\JobsController@spCheckQrCodeJobStart');
Route::post('getjobprice','Api\JobsController@getJobPriceCal');
Route::post('getspjoblocation','Api\JobsController@getLatLongOfSP');
Route::post('updatespjoblocation','Api\JobsController@updateLatLongOfSP');

Route::post('getjobsbyrole','Api\GroomController@getJobsByUserorSP');
Route::post('getjobsbymainservice','Api\GroomController@getJobByMainServices');
Route::post('getjobdetails','Api\JobsController@getJobDetailsEnquery');
Route::post('addjobrequest','Api\GroomController@addSPJobRequest');
Route::post('getjobrequestdetails','Api\GroomController@getJobRequestDetails');
Route::post('getjobsbyquestioncats','Api\GroomController@getJobByQuestionCategory');
