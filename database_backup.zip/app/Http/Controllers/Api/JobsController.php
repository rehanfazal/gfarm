<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Models\UserSession;
use App\Models\UserLogs;
use App\Models\Users;
use App\Models\UserDetails;
use App\Models\TokenCode;
use App\Models\Helper;
use App\Models\Jobs;
use App\Models\JobQrCode;
use App\Models\Services;
use App\Models\JobQuestion;
use App\Models\JobQuestionOption;
use App\Models\UserLocation;
use App\Models\Question;
use App\Models\QuestionOption;
use URL;

class JobsController extends Controller
{
	public function getJobsList(Request $request){
		$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
        	$allJobs = Helper::getJobsListing();
        	if($allJobs){
            	return $this->resp(1,"Jobs Listing",['jobs' => $allJobs]);
        	}
        	else{
            	return $this->resp(0,"Job does not exist!",['jobs' => NULL]);
            }
        }
	    else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
	}

    public function getSPJobsList(Request $request){
        $data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $allJobs = Helper::getSPJobsListing($request->user_id);
            if($allJobs){
                return $this->resp(1,"Jobs Listing",['jobs' => $allJobs]);
            }
            else{
                return $this->resp(0,"Job does not exist!",['jobs' => NULL]);
            }
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }
    // Old function of add Job - Commenting on 24th Aug, 2021
	/*public function addJobs(Request $request){
		$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
			$validator = Validator::make($request->all(), [
	            'title' => 'required',
	            'details' => 'required',
	            'service_id' => 'required',
	            'q_id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return $this->resp(0,"Add Job Failed",['error' => 'Fill the required fields!']);
	        }

	        $addJob = Helper::addJob($request);
            // dd($addJob);
	        if(isset($addJob)){
	        	$addImages = Helper::addJobImages($request,$addJob->id);
	        	if($addImages){
	        		$addJob->images = Helper::getJobImages($addJob->id);
		            return $this->resp(1,"Job added successfully!",['job' => $addJob]);
	        	}
		        else{
		            return $this->resp(1,"Job added without images!",["job" => $addJob]);
		        }
	        }
	        else{
	            return $this->resp(0,"Unable to add job!",["error" => "Unable to add job!"]);
	        }
	    }
	    else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
	}*/

    //  New Add Job Code
    public function addJobs(Request $request){
		$data = $request->all();
        // dump($data);
        // // $data = json_decode($data);
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
			$validator = Validator::make($request->all(), [
	            'title' => 'required',
	            'details' => 'required',
	            'service_id' => 'required',
	            'q_id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return $this->resp(0,"Add Job Failed",['error' => 'Fill the required fields!']);
	        }

            $newJob = new Jobs();
            $getMainFields = Services::select("*")->where('id',$request->service_id)->first();
            $main_cat = (isset($getMainFields)) ? $getMainFields->id : NULL;
            $newJob->service_id = $main_cat;
            // $newJob->q_id = (isset($getMainCat)) ? $getMainCat->id : NULL;
            $newJob->user_id = $request->user_id;
            $newJob->title = $request->title;
            $newJob->details = $request->details;
            $newJob->location = (isset($request->location)) ? $request->location : NULL;
            $newJob->latitude = (isset($request->latitude)) ? $request->latitude : NULL;
            $newJob->longitude = (isset($request->longitude)) ? $request->longitude : NULL;
            $newJob->urgent = (isset($request->urgent)) ? $request->urgent : NULL;
            $newJob->status = 0;
            $newJob->total_price = (isset($request->total_price)) ? floatval($request->total_price) : NULL;
            $newJob->save();
            
            $total_price = 0;
            $questions = $request->q_id;
            foreach($questions as $q){
                //check for questions and if exists then insert to DB
                $quest = Question::find($q['id']);
                if($quest){
                    $newQues = new JobQuestion();
                    $newQues->job_id = $newJob->id;
                    $newQues->q_id = $q['id'];
                    $newQues->save();

                    // going to add question options and quantity
                    if(isset($q["options"][0])){
                        foreach($q["options"] as $qoption){
                            // dump($qoption);
                            // echo "QO ID: ".$qoption["id"]."<br>";
                            $qPrice = QuestionOption::where("id",$qoption["id"])->first();
                            if($qPrice){
                                $qo = new JobQuestionOption();
                                $qo->job_id = $newJob->id;
                                $qo->q_id = $q['id'];
                                $qo->q_option_id = $qoption["id"];
                                $qo->quantity = $qoption["quantity"];
                                $qo->save();

                                $total_price += $qPrice->total_price;
                            }
                        }
                    }
                }
            }
                
            $latJob = Jobs::find($newJob->id);
            // $latJob->total_price = $total_price;
            $latJob->save();

	        $addImages = Helper::addJobImages($request,$latJob->id);
	        // if($addImages){
	        	$jQuestions = $latJob->getQuestion;
                foreach($jQuestions as $jQ){
                    $jQoptions = $jQ->getJobQuestionOptions($latJob->id,$jQ->q_id);
                    foreach($jQoptions as $jqOp){
                        $jqOp->q_option = $jqOp->getQuestionOption;
                    }
                    $jQ->details = $jQ->getQuestion;
                    $jQ->options = $jQoptions;
                }
	        	$latJob->questions = $jQuestions;
	        	$latJob->images = Helper::getJobImages($latJob->id);
		        return $this->resp(1,"Job added successfully!",['job' => $latJob]);
	        // }
		    // else{
		    //     return $this->resp(1,"Job added without images!",["job" => $latJob]);
		    // }
	    }
	    else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
	}

    public function getJobDetailsEnquery(Request $request){
        $data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->resp(0,"Job Detail Fetched Failed",['error' => 'Fill the required fields!']);
            }

            $jobsarr = Helper::getJobDetails($request->job_id);
            if(!empty($jobsarr)){
                // $jobsarr["job_requests"] = Helper::getJobRequest($jobsarr["id"]);

                return $this->resp(1,"Job Details Fetched",['job' =>$jobsarr]);
            }
            else{
                return $this->resp(0,"Unable to find job",['job' =>NULL]);
            }
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function acceptSPJobRequest(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }

            $checkDuplicate = Jobs::where("sp_id",$request->user_id)->whereIn("status",[1,2])->get();
            if($checkDuplicate->IsNotEmpty() && $checkDuplicate->count()>=2){
                return $this->resp(0,"Job already assigned!",['error' => 'Job already assigned!']);
            }

            $getJob = Jobs::find($request->job_id);
            if($getJob){
                if($getJob->sp_id){
                    return $this->resp(0,"Job already assigned!",['error' => 'Job already assigned!']);
                }
                $getJob->sp_id = $request->user_id;
                // $getJob->sp_job_accept = date("Y-m-d H:i:s");
                $getJob->status = 1;
                $getJob->save();

                require(app_path().'/Functions/index.php');

                $qrcode = new JobQrCode();
                $qrcode->job_id = $request->job_id;
                $qrcode->sp_id = $request->user_id;
                $qrcode->user_id = $getJob->user_id;
                $str=rand();
    	        $result = md5($str);
                $result .= 'r'.$request->user_id;
                $content = $result;//URL::to('api/test-url-for-sp-reached-at-location');
                $filename = createQRCode($content);
                // dd($result);
                $qrcode->qrcode_value = $result;
                $qrcode->qrcode_type = 1; //1- for SP side, 2 - Payment
                $qrcode->qrcode_path = $filename;
                $qrcode->status = 1;
                // dd($qrcode);
                $qrcode->save();

                return $this->resp(1,"Job Assigned",['job' => $getJob]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function spGetQRCode(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }

            $getJob = Jobs::find($request->job_id);
            if($getJob){
                $getQr = JobQrCode::where("job_id",$request->job_id)->where('sp_id',$request->user_id)->where('status',1)->first();
                if($getQr){
                    $getQr->full_path = URL::to($getQr->qrcode_path);
                    return $this->resp(1,"Job Start Qr Code",['qr_code' => $getQr]);
                }
                return $this->resp(0,"Unable to find Qr Code!",['qr_code' => NULL]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }


    public function userGetQRCode(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }

            $getJob = Jobs::find($request->job_id);
            if($getJob){
                $getQr = JobQrCode::where("job_id",$request->job_id)->where('user_id',$request->user_id)->where('status',1)->first();
                if($getQr){
                    $getQr->full_path = URL::to($getQr->qrcode_path);
                    return $this->resp(1,"Job Start Qr Code",['qr_code' => $getQr]);
                }
                return $this->resp(0,"Unable to find Qr Code!",['qr_code' => NULL]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function spCheckQrCodeJobStart(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
                'qrcode_value' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }
            
            $checkAssignedJobs = Jobs::where("sp_id",$request->user_id)->where('status',2)->get();
            if(isset($checkAssignedJobs[0])){
                return $this->resp(0,"Jobs already in queue!",['error' => 'Complete the assigned jobs first!']);
            }

            $getJob = Jobs::find($request->job_id);
            $qrcode_value = $request->qrcode_value;
            if($getJob){
                $ex = explode("r",$qrcode_value);
                $exLength = count($ex);
                $sp_id = $ex[$exLength-1];
                $getQr = JobQrCode::where("job_id",$request->job_id)->where('sp_id',$request->user_id)->where('status',1)->first();
                if($getQr){
                    $getJob->sp_job_accept = date("Y-m-d H:i:s");
                    $getJob->status = 2;
                    $getJob->save();

                    $getQr->delete();// Delete QR Code to prevent re-use

                    return $this->resp(1,"Job Started",['job' => $getJob]);
                }
                return $this->resp(0,"Unable to start job!",['error' => "Probably Wrong Person Arrived!"]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function userCheckQrCodeJobStart(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
                'qrcode_value' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }

            $getJob = Jobs::find($request->job_id);
            $qrcode_value = $request->qrcode_value;
            if($getJob){
                $ex = explode("r",$qrcode_value);
                $exLength = count($ex);
                $sp_id = $ex[$exLength-1];
                $getQr = JobQrCode::where("job_id",$request->job_id)->where('user_id',$request->user_id)->where('sp_id',$sp_id)->where('status',1)->first();
                if($getQr){
                    $getJob->status = 2;
                    $getJob->save();

                    $getQr->delete();// Delete QR Code to prevent re-use

                    return $this->resp(1,"Job Started",['job' => $getJob]);
                }
                return $this->resp(0,"Unable to start job!",['error' => "Probably Wrong Person Arrived!"]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function changeJobStatus(Request $request){
    	$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
                'status' => 'required'
            ]);
            if ($validator->fails()){
                return $this->resp(0,"Fill the required field!",['error' => 'Fill the required fields!']);
            }

            $getJob = Jobs::find($request->job_id);
            if($getJob){
                $getJob->status = $request->status;
                $getJob->save();

                $jobsarr = Helper::getJobDetails($request->job_id);

                return $this->resp(1,"Job Status Updated!",['job' => $jobsarr]);
            }
            return $this->resp(0,"Unable to find job",['error' => "Unable to find job"]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }

    public function getJobPriceCal(Request $request){
        $data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->resp(0,"Add Job Failed",['error' => 'Fill the required fields!']);
            }

            $job = Helper::getJobPriceCalculated($request->job_id);
            return $this->resp(1,"Job Price",['price' => $job]);
        }
        else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
    }
    
	public function updateLatLongOfSP(Request $request){
		$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
                'latitude' => 'required',
                'longitude' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->resp(0,"SP Location Update Failed",['error' => 'Fill the required fields!']);
            }
            $newLoc = new UserLocation();
            $newLoc->user_id = $request->user_id;
            $newLoc->latitude = $request->latitude;
            $newLoc->longitude = $request->longitude;
            $newLoc->job_id = $request->job_id;
            $newLoc->save();
            
            return $this->resp(1,"SP Location Update",['location' => $newLoc]);
        }
	    else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
	}

	public function getLatLongOfSP(Request $request){
		$data = $request->all();
        if(!isset($data['token'])){
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
        if($this->checkToken($data['token'],$data['user_id']) == 1){
            $validator = Validator::make($request->all(), [
                'job_id' => 'required',
            ]);
            if ($validator->fails()) {
                return $this->resp(0,"SP Location Failed",['error' => 'Fill the required fields!']);
            }
            $job = Jobs::find($request->job_id);
            if($job){
                // echo "SP_ID: ".$job->sp_id." Job ID: ".$job->id."\n";
                $latestLoc = UserLocation::where("job_id",$job->id)->where("user_id",$job->sp_id)->orderBy("id","desc")->first();
                if($latestLoc){
                    return $this->resp(1,"SP Location",['location' => $latestLoc]);
                }
                else{
                    return $this->resp(0,"SP location does not exist!",['location' => NULL]);
                }
            }
            else{
                return $this->resp(0,"Unable to find job!",['location' => NULL]);
            }
        }
	    else {
            return $this->resp(0,"Token Mismatch",['user' => NULL]);
        }
	}

    function checkToken($token,$userid){
        $checkt = UserSession::where('remember_token','=',$token)->where('user_id','=',$userid)->first();
        if($checkt){
            return 1;
        }
        else {
            return 0;
        }
    }

    function resp($success, $message, $data = [])
    {
        $resp ['success'] = $success;
        $resp['message'] = $message;
        if (!empty($data)){
            $resp['data'] = $data;
        }
        return response()->json($resp);
    }
}
