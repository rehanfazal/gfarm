<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Models\UserSession;
use App\Models\UserLogs;
use App\Models\Users;
use App\Models\UserDetails;
use App\Models\TokenCode;
use App\Models\Helper;
use App\Models\Roles;
use App\Models\Services;
use App\Models\Question;
use App\Models\QuestionOption;
use App\Models\Activities;
use App\Models\Classification;
use App\Models\ClassificationQuestionOption;
use App\Models\ActivitiesQuestionOption;
use Input;


class AdminController extends Controller
{
	public function adminLogin(Request $request){
		if($request->IsMethod("get")){
			return view('login');
		}
	}

	public function mobileSignUp(Request $request){
		$validator = Validator::make($request->all(), [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
            'password' => 'required',
            'confirm_password' => 'required'
        ]);
        if ($validator->fails()) {
            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
        }
        if ($request->password != $request->confirm_password){
            return redirect()->back()->withErrors(['error' => 'Password Do Not Match!']);
        }

    	$data = $request->all();

        $hash = password_hash($request->password, PASSWORD_DEFAULT);

    	$dup = Users::select('*')->where('email','=',$request->email)->first();
    	if ($dup){
            return redirect()->back()->withErrors(['error' => 'Email Already Exist!']);
    	}
    	$newUser = new Users();
    	$newUser->first_name = $request->first_name;
    	$newUser->last_name = $request->last_name;
    	$newUser->email = $request->email;
    	$newUser->password = $hash;
    	$newUser->status = 1;
    	$newUser->save();

    	Session::flash('response',"Account Created Successfully!");
    	return redirect(route('admin-login'));
	}

	public function otpConfirmViaEmail(Request $request){
		$tokenValue = $request->confirmtoken;
		$userid = $request->userid;
		$tokenmatch = TokenCode::select('*')->where('user_id','=',$userid)->where('tokenforemail','=',$tokenValue)->first();
		if($tokenmatch){
			$useractive = Users::find($userid);
			$useractive->status = 1;
			$useractive->save();

			$delTokenCode = TokenCode::find($tokenmatch)->first()->delete();

    		return $this->resp(1,"Signup Successful",['user' => $useractive]);
		}
		else {
    		return $this->resp(0,"Invalid Pin",['user' => NULL]);
		}
	}

    public function mobilelogin(Request $request){
    	if($request->IsMethod("post")){
			$validator = Validator::make($request->all(), [
	            'email' => 'required',
	            'password' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $userCheck = Users::select('*')->where('email',$request->email)->first();

	        if ($userCheck){
                if (password_verify($request->password, $userCheck->password)) {
                	Session::put('user',$userCheck);
                	Session::put('email',$userCheck->email);
    	            return redirect(route('admin-dashboard'));
                }
                else{
            		return redirect()->back()->withErrors(['error' => 'Wrong email or password!']);
                }
	        }
	        else {
            	return redirect()->back()->withErrors(['error' => 'Wrong email or password!']);
	        }
    	}
    }

    public function adminLogout(Request $request){
    	Session::forget('user');
        Session::forget('email');
    	return redirect(route('admin-login'));
    }

    public function forgetPassword(Request $request){
    	if($request->IsMethod("post")){
    		$email = $request->email;

	    	$newUser = Users::select('*')->where('email','=',$email)->first();
	    	if($newUser){
	    		$six_digit_random_number = 111222;//mt_rand(100000, 999999);
		    	$token = new TokenCode();
		    	$token->tokenforemail = $six_digit_random_number;
		    	$token->user_id = $newUser->id;
		    	$token->save();
				$newUser->tokenotp = $six_digit_random_number;
		    	// the message
				$msg = "Forget Password\nKindly Enter the Below Verification Code to verify it's You\n".$six_digit_random_number;

				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,70);

				// send email
				// $checkError = mail($request->email,"Forgot Password",$msg);
                $checkError = true;
				if($checkError){
					$newUser->emailstatus = "Email Sent";
		        	return $this->resp(1,"Code Sent Successfully",['user' => $newUser]);
				}
				else{
					$newUser->emailstatus = "Email Not Sent";
		        	return $this->resp(0,"Unable to Send Code",['user' => $newUser]);
				}
	    	}
	    	else{
	    		return $this->resp(0,"User Does Not Exist",['user' => NULL]);
	    	}
    	}
    }

    public function dashboard(Request $request){
    	$users = Users::get();
    	$userCount = count($users);
    	$mainCats = NULL;//Services::get();
    	$mCatCount = 0;

    	return view('admin.dashboard',['userCount'=>$userCount,'mCatCount'=>$mCatCount,'page_name' => 'dashboard']);
    }

    public function listServices(Request $request){
    	if($request->IsMethod("get")){
	    	$allCats = Services::paginate(15);

	    	return view('admin.services',['services'=>$allCats,'page_name' => 'services']);
	    }
	    if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'service_name' => 'required'
	        ]);
	        if ($validator->fails()) {
				Session::flash("error","Fill the required fields!");
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!'])->withInput();
	        }

	        $newCat = new Services();
			if(isset($request->id)){
				$newCat = Services::find($request->id);
			}
	        $newCat->name = $request->service_name;
			$filename = NULL;

			if($request->hasFile("service_image")){
				$file = $request->file('service_image');
				$filename = 'serviceImages/category'.date("Ymd-his").'.'.$file->getClientOriginalExtension();
				$destinationPath = "public/images/".$filename;
				if (move_uploaded_file($_FILES['service_image']['tmp_name'],$destinationPath)){
					if (file_exists($destinationPath)) {
						$newCat->image = $filename;
					}
				}
			}

	        $newCat->save();

			if(isset($request->id)){
				Session::flash("success","Service has updated successfully!");
			}
			else{
				Session::flash("success","Service has added successfully!");
			}
	        return redirect(route('admin-main-services'));
	    }
    }

	public function getMainSubCategories(Request $request){
		if($request->IsMethod("get")){
			$mainCats = MainCategory::find($request->main_cat_id);
			if($mainCats){
				$mainCategory = $mainCats;
	        	$allCats = Helper::getSubCats($request->main_cat_id);
	        	if($allCats){
	            	return view('admin.subcategories',['categories' => $allCats,'mainCategory'=>$mainCategory,'page_name'=>'categories']);
	        	}
	        	else{
	            	return view('admin.subcategories',['categories' => NULL,'mainCategory'=>$mainCategory,'page_name'=>'categories']);
	        	}
			}
			else{
				Session::flash("error","Unable to fetch categories");

				return redirect()->back();
	        }
	    }
	    if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'category_name' => 'required',
	            'main_cat_id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $newCat = new SubCategory();
			if(isset($request->id)){
				$newCat = SubCategory::find($request->id);
			}

	        $newCat->category_name = $request->category_name;
	        $newCat->main_cat_id = $request->main_cat_id;
			$filename = NULL;

			if($request->hasFile("category_image")){
				$file = $request->file('category_image');
				$filename = 'categoryImages/category'.date("Ymd-his").'.'.$file->getClientOriginalExtension();
				$destinationPath = "public/images/".$filename;
				if (move_uploaded_file($_FILES['category_image']['tmp_name'],$destinationPath)){
					if (file_exists($destinationPath)) {
						$newCat->image = $filename;
					}
				}
			}

	        $newCat->save();

			if(isset($request->id)){
				Session::flash("success","Sub Category has updated successfully!");
			}
			else{
				Session::flash("success","Sub Category has added successfully!");
			}
	        return redirect(route('admin-main-sub-category',['main_cat_id'=>$request->main_cat_id]));
	    }

	}

    public function editCategory(Request $request){
    	if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'id' => 'required',
	            'category_name' => 'required',
	            'fr' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $up = MainCategory::find($request->id);
	        if($up){
	        	$up->category_name = $request->category_name;
	        	$up->fr = $request->fr;
	        	$up->save();

	        	Session::flash("message","Category Name Updated!");
	        	return redirect(route('categories'));
	        }
	        else{
	        	return redirect()->back()->withErrors(['error'=>'Unable to locate category!']);
	        }
	    }
    }

    public function deleteCategory(Request $request){
    	if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $up = VehicleCategory::find($request->id);
	        if($up){
	        	//$findSub = VehicleSubCategory::where('parent_cat_id',$request->id)->delete();
	        	$up->status = 0;
	        	$up->save();
	        	//$up->delete();

	        	Session::flash("message","Category and its Sub Categories Deleted!");

	        	return redirect(route('categories'));
	        }
	        else{
	        	return redirect()->back()->withErrors(['error'=>'Unable to locate category!']);
	        }
	    }
    }

    public function editSubCategoryAdmin(Request $request){
    	if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'id' => 'required',
	            'subcategory' => 'required',
	            'category_name' => 'required',
	            'fr' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $up = VehicleSubCategory::find($request->subcategory);
	        if($up){
	        	$up->category_name = $request->category_name;
	        	$up->fr = $request->fr;
	        	$up->save();

	        	Session::flash("message","Sub Category Updated!");
	        	return redirect(route('categories'));
	        }
	        else{
	        	return redirect()->back()->withErrors(['error'=>'Unable to locate category!']);
	        }
	    }
    }

    public function getStatusChanged(Request $request){
    	if($request->IsMethod("get")){
			$getCat = isset($request->cat_name) ? $request->cat_name : "";
			$getCatId = isset($request->cat_id) ? $request->cat_id : '';
			$getStatus = isset($request->status) ? $request->status : '';
			if ($getCat == '' || $getCatId == '' || $getStatus == ''){
			    return redirect()->back()->with('error','Something Went Wrong!');
            }
			if($getCat == 1){
				$getCathere = Services::find($getCatId);
				if($getCathere){
					$getCathere->status = $getStatus;
					$getCathere->save();

					Session::flash("success","Main Service Status Updated!");
					return redirect()->back();
				}
			}
			if($getCat == 2){
				$getQhere = Question::find($getCatId);
				if($getQhere){
					$getQhere->status = $getStatus;
					$getQhere->save();

					Session::flash("success","Question Status Updated!");
					return redirect()->back();
				}
			}
			if($getCat == 3){
				$getCathere = QuestionOption::find($getCatId);
				if($getCathere){
					$getCathere->status = $getStatus;
					$getCathere->save();

					Session::flash("success","Option Status Updated!");
					return redirect()->back();
				}
			}
			Session::flash("error","Something Went Wrong!");
			return redirect()->back();
    	}
    }

    public function getCatDeleted(Request $request){
    	if($request->IsMethod("get")){
			$getCat = $request->cat_name;
			$getCatId = $request->cat_id;

			if(intval($getCat) == 1){
				echo "CAT ID: ".$getCatId."<br>";
				$getCathere = Services::find($getCatId);
				if($getCathere){
					// Delete Question
					Question::where('service_id',$getCatId)->delete();

					// Delete QuestionOption
					QuestionOption::where('service_id',$getCatId)->delete();
					$getCathere->delete();

					Session::flash("success","Main Service Deleted!");
					return redirect()->back();
				}
				$getCathere->delete();
				Session::flash("success","Main Service Deleted!");
				return redirect()->back();
			}
			if(intval($getCat) == 2){
				$getQhere = Question::find($getCatId);
				if($getQhere){
					// Delete QuestionOption
					$delQO = QuestionOption::where('q_id',$getQhere);
					$delQO->delete();

					$getQhere->delete();

					Session::flash("success","Question Deleted!");
					return redirect()->back();
				}
				Session::flash("error","Unable to find question!");
				return redirect()->back();
			}
			if(intval($getCat) == 3){
				$getCathere = QuestionOption::find($getCatId);
				if($getCathere){
					$getCathere->delete();

					Session::flash("success","Option Deleted!");
					return redirect()->back();
				}
				Session::flash("error","Unable to find option!");
				return redirect()->back();
			}
			Session::flash("error","Something Went Wrong!");
			return redirect()->back();
    	}
    }

    public function getSubCatInfo(Request $request){
    	if($request->ajax()){
    		$validator = Validator::make($request->all(), [
	            'id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $getSb = VehicleSubCategory::select("*")->where('id',$request->id)->first();
	        if($getSb){
	        	$ar = array('category_name_en'=>$getSb->category_name,'category_name_fr'=>$getSb->fr);
	        	return response()->json($getSb,200);
	        }
	        else{
	        	return response()->json(NULL, 200);
	        }
    	}
    }

    public function getQuestions(Request $request){
    	if($request->ajax()){
    		$validator = Validator::make($request->all(), [
	            'service_id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }

	        $getSb = Helper::getSubCats($request->service_id);
	        if($getSb){
				$htmlrender = view('admin.select_options',['category'=>$getSb])->render();
	        	return response()->json(['success'=>1,'html'=>$htmlrender],200);
	        }
	        else{
				$htmlrender = view('admin.select_options',['category'=>$getSb])->render();
	        	return response()->json(['success'=>0,'html'=>$htmlrender], 200);
	        }
    	}
    }

	public function getServiceQuestions(Request $request){
		if($request->IsMethod("get")){
			$mainCategory = Services::find($request->service_id);
			$question = Question::where('service_id',$request->service_id)->get();
			if($question){
				return view('admin.question',['questions' => $question,'mainCategory'=>$mainCategory,'page_name'=>'services']);
			}
			else{
				return view('admin.question',['questions' => NULL,'mainCategory'=>$mainCategory,'page_name'=>'services']);
			}
	    }
		if($request->IsMethod("post")){
			$validator = Validator::make($request->all(),[
				'service_id' => 'required',
				'info_text' => 'required'
			]);
			if($validator->fails()){
				Session::flash("error","Fill the required fields");
				return redirect()->back()->withInput();
			}

			$question = new Question();
			if(isset($request->id)){
				$question = Question::find($request->id);
			}
			$question->service_id = $request->service_id;
			$question->question = (isset($request->question)) ? $request->question : NULL;
			$question->info_text = (isset($request->info_text)) ? $request->info_text : NULL;
			$question->status = 1;
			$question->save();

			if(isset($request->id)){
				Session::flash("success","Question Updated!");
			}
			else{
				Session::flash("success","New Question Added!");
			}
			return redirect()->back();
		}
	}

	public function getMainSubQuestionsList(Request $request){
		if($request->ajax()){
			$question = Helper::getQuestions($request->service_id);
			// dd($question);
			if($question){
				$html = view('admin.question-select',['questions'=>$question])->render();
				return response()->json(['success'=>1,'html'=>$html]);
			}
			else{
				$html = view('admin.question-select',['questions'=>NULL])->render();
				return response()->json(['success'=>0,'html'=>$html]);
			}
	    }
	}
	public function getQuestionData(Request $request){
		$question_id=$request->question_id;

		$questionOption=QuestionOption::where('id','=',$question_id)->first();
		$ClassificationQuestionOption=ClassificationQuestionOption::where('q_o_id','=',$question_id)->get();
		$ActivitiesQuestionOption=ActivitiesQuestionOption::where('q_o_id','=',$question_id)->get();
			$classification=[];
			$activities=[];
			foreach($ActivitiesQuestionOption as $aqo){
				array_push($activities,$aqo->getAllActivity);
			}
			foreach($ClassificationQuestionOption as $cqo){

				array_push($classification,$cqo->getAllClassification);
			}

		if($questionOption){
			$data=array('status'=>200,'data'=>$questionOption,'classification'=>$classification,'activities'=>$activities);

			echo json_encode($data);die;
		}else{

		}
	}
	public function deleteSubQuestionOption(Request $request){
		$question=QuestionOption::find($request->option_id);
		if($question){

			$ActivitiesQuestionOption=ActivitiesQuestionOption::where('q_o_id','=',$request->option_id)->get();
			if($ActivitiesQuestionOption->isNotEmpty()){
					foreach($ActivitiesQuestionOption as $aqo){
					$aqo->delete();
				}
			}
			$checkclassifictaion=ClassificationQuestionOption::where('q_o_id','=',$request->option_id)->get();
			if($checkclassifictaion->isNotEmpty()){
				foreach($checkclassifictaion as $cc){
					$cc->delete();
				}
			}

			$question->delete();
			Session::flash("success","Sub Question Deleted!");
				return redirect()->back();
		}
	}
	public function getSubQuestionOption(Request $request){

		if($request->IsMethod("get")){
			$data['page_name'] = "services";
			$question = Question::find($request->q_id);
			if($question){
			$data['question'] = $question;

			$data['mainCategory'] = Services::find($question->service_id);
			$qOptions = QuestionOption::where('service_id',$question->service_id)->where('q_id',$request->q_id)->get();

			if($qOptions){
				$data['questionOption'] = $qOptions;
				return view('admin.question-option',$data);
			}
			else{
				$data['questionOption'] = NULL;
				return view('admin.question-option',$data);
			}

			}
			else{
				Session::flash("error","you enter wrong id of question");
				return redirect()->route('admin-main-services');
			}
	    }
		if($request->IsMethod("post")){
			$request->validate([
				'service_id' => 'required',
				'q_id' => 'required',
				'classification_id' => 'required',
				'activities_id' => 'required',
                'option_text' => 'required',
                'time_in_hrs' => 'required',
                'base_price' => 'required',
                'retail_product' => 'required',
                'customer_price' => 'required',
                'product_pricing' => 'required',
                'total_price' => 'required',
			]);

			$newoption = new QuestionOption();
			if($request->questionoption_id){
				$old_question_id=$request->old_question_id;

				$newoption=QuestionOption::find($request->questionoption_id);
				$newoption->service_id = $request->service_id;
				$newoption->q_id = $request->q_id;
				$newoption->time_in_hrs = $request->time_in_hrs;
				$newoption->base_price = $request->base_price;
				$newoption->option_text = $request->option_text;
				$newoption->customer_price = $request->customer_price;
				$newoption->retail_product = $request->retail_product;
				$newoption->product_pricing = $request->product_pricing;
				$newoption->total_price = $request->total_price;
				$newoption->update();
				$ActivitiesQuestionOption=ActivitiesQuestionOption::where('q_o_id','=',$old_question_id)->delete();

				foreach($request->activities_id as $newAct){
					$newActivity = new ActivitiesQuestionOption();
					$newActivity->q_o_id = $old_question_id;
					$newActivity->activity_id = $newAct;
					$newActivity->save();
				}
				$checkclassifictaion=ClassificationQuestionOption::where('q_o_id','=',$old_question_id)->delete();

				foreach($request->classification_id as $newClass){
					$newActivity = new ClassificationQuestionOption();
					$newActivity->q_o_id = $old_question_id;
					$newActivity->classification_id = $newClass;
					$newActivity->save();
				}

				Session::flash("success","Question Option updated!");
				return redirect()->back();


			}else{

				$newoption->service_id = $request->service_id;
				$newoption->q_id = $request->q_id;
				$newoption->time_in_hrs = $request->time_in_hrs;
				$newoption->base_price = $request->base_price;
				$newoption->option_text = $request->option_text;
				$newoption->customer_price = $request->customer_price;
				$newoption->retail_product = $request->retail_product;
				$newoption->product_pricing = $request->product_pricing;
				$newoption->total_price = $request->total_price;
				$newoption->save();

				foreach($request->activities_id as $newAct){
					$newActivity = new ActivitiesQuestionOption();
					$newActivity->q_o_id = $newoption->id;
					$newActivity->activity_id = $newAct;
					$newActivity->save();
				}
				foreach($request->classification_id as $newClass){
					$newActivity = new ClassificationQuestionOption();
					$newActivity->q_o_id = $newoption->id;
					$newActivity->classification_id = $newClass;
					$newActivity->save();
				}

				Session::flash("success","Question Option Added!");
				return redirect()->back();
			}
	    }
	}

	public function adminClassification(Request $request){
		if($request->IsMethod("get")){
			$data['page_name'] = "classification";
			$classy = Classification::get();
			$data['classification'] = $classy;
			if($classy){
				return view('admin.classification',$data);
			}
			else{
				return view('admin.classification',$data);
			}
	    }
		if($request->IsMethod("post")){
			$validator = Validator::make($request->all(),[
				'classy_name' => 'required'
			]);
			if($validator->fails()){
				Session::flash("error","Fill the required fields!");
				return redirect()->back();
			}

			$classy = new Classification();
			if(isset($request->id)){
				$classy = Classification::find($request->id);
			}
			else{
				$classy->status = 1;
			}
			$classy->name = $request->classy_name;
			$classy->save();

			if(isset($request->id)){
				Session::flash("success","Classification Updated!");
				return redirect()->back();
			}
			else{
				Session::flash("success","Classification Added!");
				return redirect()->back();
			}
	    }
	}

	public function adminChangeClassyStatus(Request $request){
		if($request->IsMethod("get")){
			$data['page_name'] = "classification";
			$classy = Classification::find($request->class_id);
			if($classy){
				if($request->status == 1 || $request->status == 0){
					$classy->status = $request->status;
					$classy->save();

					Session::flash("success","Classification Status Updated!");
					return redirect()->back();
				}
				if($request->status == 2){
					$getAllSetQOption = Classification::where("id",$request->classy_id)->first();
					$getAllSetQOption->getQuestionOptions()->detach();

					$classy->delete();

					Session::flash("success","Classification Deleted!");
					return redirect()->back();
				}
			}
			else{
				Session::flash("error","Something went wrong");
				return redirect()->back();
			}
	    }
	}


	public function adminActivities(Request $request){
		if($request->IsMethod("get")){
			$data['page_name'] = "activities";
			$classy = Activities::get();
			$data['activities'] = $classy;
			if($classy){
				return view('admin.activities',$data);
			}
			else{
				return view('admin.activities',$data);
			}
	    }
		if($request->IsMethod("post")){
			$validator = Validator::make($request->all(),[
				'classy_name' => 'required'
			]);
			if($validator->fails()){
				Session::flash("error","Fill the required fields!");
				return redirect()->back();
			}

			$classy = new Activities();
			if(isset($request->id)){
				$classy = Activities::find($request->id);
			}
			else{
				$classy->status = 1;
			}
			$classy->name = $request->classy_name;
			$classy->save();

			if(isset($request->id)){
				Session::flash("success","Activity Updated!");
				return redirect()->back();
			}
			else{
				Session::flash("success","Activity Added!");
				return redirect()->back();
			}
	    }
	}

	public function adminChangeActivityStatus(Request $request){
		if($request->IsMethod("get")){
			$data['page_name'] = "activities";
			$classy = Activities::find($request->activity_id);
			if($classy){
				if($request->status == 1 || $request->status == 0){
					$classy->status = $request->status;
					$classy->save();

					Session::flash("success","Activity Status Updated!");
					return redirect()->back();
				}
				if($request->status == 2){

					$getAllSetQOption = Activities::where("id",$request->activity_id)->first();
					$getAllSetQOption->getQuestionOption()->detach();

					Session::flash("success","Activity Deleted!");
					return redirect()->back();
				}
			}
			else{
				Session::flash("error","Something went wrong.");
				return redirect()->back();
			}
	    }
	}

    public function userSearch(Request $request){
    	if($request->IsMethod("post")){
	    	$users = Users::select("*")->where('users.role_id','!=',1)->where('username',"LIKE","%".$request->search."%")
                ->join('user_details as ud','users.id','ud.user_id')->paginate(15);
	    	if($users->IsNotEmpty()){
				foreach($users as $u){
					$u->name = ucwords($u->first_name." ".$u->last_name);
					$role = Roles::find($u->role_id);
					$u->role = ucwords($role->role_name);
				}
				$rolesAll = Roles::get();
				// Session::flash("error","This is the error");
				$html = view("admin.userajax")->with("users",$users)->with('roles',$rolesAll)->render();
				return response()->json(['success'=>1,'html'=>$html,'message'=>"Users Fetched!"]);
			}
			return response()->json(['success'=>0,'html'=>NULL,'message'=>"User not found!"]);
		}
	}
	
    public function userListing(Request $request){
    	if($request->IsMethod("get")){
	    	$users = Users::select("*")->where('users.role_id','!=',1)
                ->join('user_details as ud','users.id','ud.user_id')->paginate(15);
	    	foreach($users as $u){
	    		$u->name = ucwords($u->first_name." ".$u->last_name);
	    		$role = Roles::find($u->role_id);
	    		$u->role = ucwords($role->role_name);
	    	}
	    	$rolesAll = Roles::get();
	    	// Session::flash("error","This is the error");
		    return view('admin.users',['roles'=>$rolesAll,'users'=>$users,'page_name' => 'users']);
		}
		if($request->IsMethod("post")){
			$validator = Validator::make($request->all(), [
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required',
                'password' => 'required',
                'confirm_password' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }
	        if ($request->password != $request->confirm_password){
	            return redirect()->back()->withErrors(['error' => 'Password Do Not Match!']);
	        }

	    	$data = $request->all();

	        $hash = password_hash($request->password, PASSWORD_DEFAULT);

	    	$dup = Users::select('*')->where('email','=',$request->email)->first();
	    	if ($dup){
	            return redirect()->back()->withErrors(['error' => 'Email already exists!']);
	    	}

	    	$newUser = new Users();
	    	$newUser->first_name = $request->first_name;
	    	$newUser->last_name = $request->last_name;
	    	$newUser->email = $request->email;
	    	$newUser->password = $hash;
	    	$newUser->role_id = $request->role;
	    	$newUser->status = 1;
	    	$newUser->save();

	    	Session::flash("message","User added successfully!");
	        return redirect(route('users'));
		}
    }

    public function changePass(Request $request){
    	if($request->IsMethod("post")){
			$validator = Validator::make($request->all(), [
                'current_pass' => 'required',
                'password' => 'required',
                'confirm_password' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }
	        if ($request->password != $request->confirm_password){
	            return redirect()->back()->withErrors(['error' => 'Password Do Not Match!']);
	        }

	    	$data = $request->all();

	    	$dup = Users::select('*')->where('id',Session::get('user')->id)->first();
	    	if ($dup){
	    		if (password_verify($request->current_pass, $dup->password)){
		    		$hashe = password_hash($request->password, PASSWORD_DEFAULT);

			    	$dup->password = $hashe;
			    	$dup->save();

			    	Session::flash("message","Password change successfull!");

			        return redirect(route('users'));
		        }
	        	return redirect()->back()->withErrors(['error' => 'Current password is wrong!']);
	    	}
	        return redirect()->back()->withErrors(['error' => 'Unable to locate user!']);
		}
    }

    public function editUser(Request $request){
    	if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'id' => 'required',
                'role_id' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'phone' => 'required'
	        ]);
	        if ($validator->fails()) {
	    		Session::flash("error","Fill the required fields!");
	            return redirect()->back()->withInput();
	        }

	        $userMain = Users::find($request->id);
	    	if($userMain){
	    		$userMain->role_id = $request->role_id;
	    		$userMain->save();

	    		$user = UserDetails::select("*")->where("user_id",$request->id)->first();
	    		$user->first_name = $request->first_name;
	    		$user->last_name = $request->last_name;
	    		$user->phone = $request->phone;
	    		$user->birthday = $request->birthday;
	    		$user->location = $request->location;
	    		$user->save();

	    		Session::flash("success","User updated successfully!");
	    		return redirect(route('admin-users'));
	    	}
	    	else{
	    		Session::flash("error","Unable to locate user!");
	            return redirect()->back();
	    	}
	    }
    }
    public function userDelete(Request $request){
    	if($request->IsMethod("post")){
	    	$validator = Validator::make($request->all(), [
	            'id' => 'required'
	        ]);
	        if ($validator->fails()) {
	            return redirect()->back()->withErrors(['error' => 'Fill the required fields!']);
	        }
	    	$user = Users::find($request->id);
	    	if($user){
	    		$user->delete();
	    		Session::flash("message","User deleted successfully!");
	    		return redirect(route('users'));
	    	}
	    	else{
	            return redirect()->back()->withErrors(['error' => 'Unable to locate user!']);
	    	}
	    }
    }
}
