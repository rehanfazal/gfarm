<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Models\UserSession;
use App\Models\UserLogs;
use App\Models\Users;
use App\Models\UserDetails;
use App\Models\TokenCode;
use App\Models\Helper;
use App\Models\Roles;
use App\Models\Jobs;
use App\Models\MainCategory;
use App\Models\SubCategory;

class JobsController extends Controller
{
    function getAllJobs(Request $request){
        if($request->IsMethod("get")){
            $getJobs = Jobs::orderBy("id","desc")->paginate(30);
            // dd($getJobs);
            $data['jobs'] = $getJobs;
            $data['page_name'] = "jobs";
            return view("admin.jobs",$data);
        }
        if($request->IsMethod("post")){

        }
    }
    public function serviceProviderJobs(Request $request){
    	
    }
    public function viewJob(Request $request){
    	if($request->IsMethod("get")){
            $jobid = $request->job_id;
            $job = Jobs::find($jobid);
            if($job){
                $job = Helper::getJobDetails($jobid);
                $data['job'] = $job;
                $data['page_name'] = "jobs";
                return view("admin.viewjob",$data);
            }
        }
        return redirect()->back();
    }
}
