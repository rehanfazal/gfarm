<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobQrCode extends Model
{
    protected $table = "job_qrcode";

    protected function getJob(){
        return $this->hasOne(Jobs::class,'id','job_id');
    }
}
