<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserCreditCard extends Model
{
    protected $table = "user_credit_card";

    protected function getUser(){
        return $table->hasOne(Users::class,'id','user_id');
    }
}
