<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Classification extends Model
{
    protected $table = "classification";

	protected function getQuestionOptions(){
        return $this->belongsToMany(QuestionOption::class,'classification_question_option','classification_id','q_o_id');
    }
}
