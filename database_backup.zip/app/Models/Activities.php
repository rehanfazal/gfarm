<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Activities extends Model
{
    protected $table = "activities";

    protected function getQuestionOption(){
        return $this->belongsToMany(QuestionOption::class,'activities_question_option','activity_id','q_o_id');
    }
}
