<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuestionOption extends Model
{
    protected $table = "question_options";
    
	protected function getJobOption(){
        return $this->belongsToMany(Jobs::class,'jobs_question_options','job_id','q_option_id');
	}

	protected function getActivities(){
        return $this->belongsToMany(Activities::class,'activities_question_option','activity_id','q_o_id');
    }

	protected function getClassification(){
        return $this->belongsToMany(Classification::class,'classification_question_option','classification_id','q_o_id');
    }
	protected function getMainCategory(){
        return $this->hasOne(MainCategory::class,'id','main_cat_id');
	}
	protected function getSubCategory(){
        return $this->hasOne(SubCategory::class,'id','sub_cat_id');
	}
	protected function getQuestion(){
        return $this->hasOne(Question::class,'id','q_id');
	}
	protected function getJobQuestionOption(){
        return $this->belongsTo(JobQuestionOption::class,'q_option_id','id');
	}
}
