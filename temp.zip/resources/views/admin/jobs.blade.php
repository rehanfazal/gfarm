@extends('admin.master')

@section('content')
<div class="row">
    <div class="col-lg-12 col-md-12">
        <div class="card">
            <div class="card-header card-header-danger">
                <h4 class="card-title">Jobs</h4>
                <p class="card-category">All Jobs</p>
           </div>
            <div class="card-body table-responsive">
                @if(!isset($jobs[0]))
                    <div class="text-warning">
                      No Job Found!
                    </div>
                @else
                <table class="table table-hover">
                    <thead class="text-danger">
                      <th>S.#</th>
                      <th>SP</th>
                      <th>Title</th>
                      <!-- <th>Description</th> -->
                      <th>Date Created</th>
                      <th>Status</th>
                      <th>Total Price</th>
                      <th>Action</th>
                    </thead>
                    <tbody>
                      @php $counter = 1; @endphp
                      @foreach($jobs as $sUser)
                      <tr>
                        <td>{{ $counter }}</td>
                        <td>
                            @php $spUserInfo = \App\Models\Helper::getUserInfo($sUser->sp_id); @endphp
                            @if($spUserInfo)
                            <a class="" title="View Profile" data-toggle="modal" data-target="#spView{{ $sUser->id }}">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </a> &nbsp;
                            <div class="modal" id="spView{{ $sUser->id }}" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content card card-profile">
                                    <div class="card-avatar">
                                        <a href="javascript:;">
                                        <img class="img" src="
                                        @if($spUserInfo->profile_image)
                                            {{ URL::to('public/images/'.$spUserInfo->profile_image) }}
                                        @else
                                            {{ URL::to('public/images/userImages/no-user.png') }}
                                        @endif" />
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <h6 class="card-category text-gray">{{ $spUserInfo->role }}</h6>
                                        <h4 class="card-title">{{ ucwords($spUserInfo->first_name." ".$spUserInfo->last_name) }}</h4><hr>
                                        <div class="card-description row" style="color:black;">
                                        <div class="col-sm-6">
                                            Birthday: {{ $spUserInfo->birthday }}<br>
                                        </div>
                                        <div class="col-sm-6">
                                            Email: {{ $spUserInfo->email }}<br>
                                            Phone: {{ $spUserInfo->phone }}<br>
                                        </div>
                                        <div class="col-sm-12">
                                            Location: {{ $spUserInfo->location }}<br>
                                        </div>
                                        </div>
                                        <button type="button" class="btn btn-danger btn-round" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                                </div>
                            </div>
                            @endif
                        </td>
                        <td>{{ $sUser->title }}</td>
                        <!-- <td>{{ $sUser->details }}</td> -->
                        <td>{{ date("Y-m-d H:i:s",strtotime($sUser->created_at)) }}</td>
                        <td>{{ $sUser->status }}
                        {{-- \App\Models\Helper::getJobStatusName($sUser->status) --}}
                        </td>
                        <td>{{ $sUser->total_price }}</td>
                        <td>

                            <a href="{{ route('admin-view-job',['job_id'=>$sUser->id])}}" class="" title="View Job">
                                <i class="fa fa-eye" aria-hidden="true"></i>
                            </a> &nbsp;
                        {{--<div class="modal" id="myModal{{ $sUser->id }}" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">{{ $sUser->title }} Job Details</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i class="material-icons">clear</i>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group row">
                                        <div class="col-sm-12">
                                            <label>Job Description:</label>
                                            <p class="">{{ $sUser->description }}</p>
                                            
                                            <label>Job Question:</label>
                                            @php 
                                                $qOptions = NULL;
                                            @endphp
                                            @if(isset($sUser->getQuestion))
                                            @php 
                                                $qOptions = $sUser->getQuestion->getQuestionOption;
                                            @endphp
                                            <p class="">{{ $sUser->getQuestion->question }}</p>
                                            <label>Job Info Text:</label>
                                            <p class="">{{ $sUser->getQuestion->info_text }}</p>
                                            @endif
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-12">
                                                <label>Job Question Options:</label>
                                            </div>
                                            @php 
                                                $jobQOptions = $sUser->getQuestionOption;  
                                                //($jobQOptions);
                                                $innercounter = 0;
                                                $totalPrice = 0;
                                                $checked = '';
                                                if($jobQOptions->count()>0){
                                                    foreach($jobQOptions as $jQ){ 
                                                        if($jQ->getQuestionOption){
                                                            $totalPrice += $jQ->getQuestionOption->total_price;
                                                        @endphp
                                                    <div class="col-sm-12">
                                                        <input type="checkbox" readonly checked class=""/>{{ $jQ->getQuestionOption->option_text }}
                                                    </div>
                                            @php
                                                        }
                                                    }
                                                }
                                            @endphp
                                            @if(isset($qOptions[0]))
                                            @foreach($qOptions as $qo)
                                            @php 
                                                $checked = '';
                                                if($jobQOptions->count()>0){
                                                    foreach($jobQOptions as $jQ){
                                                        if($jQ->q_option_id == $qo->id){
                                                            $checked = 'checked';
                                                        }
                                                    }
                                                }
                                            @endphp
                                            <!-- <div class="col-sm-12">
                                            <input type="checkbox" readonly {{ $checked }} class=""/>{{ $qo->option_text }}</div> -->
                                            @php $innercounter++; @endphp
                                            @endforeach
                                            @endif
                                            
                                            
                                            <div class="col-sm-12">
                                                <label>Total Price:</label>
                                                <p class="">{{ $totalPrice }}</p>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group row">
                                            @php 
                                                $images = $sUser->getJobImages;
                                            @endphp
                                            @if($images->isNotEmpty())
                                            @foreach($images as $img)
                                            <div class="col-sm-3">
                                            <a href="{{ asset('images/jobImages/'.$img->image) }}" target="_blank">
                                                <img src="{{ asset('images/jobImages/'.$img->image) }}" class="" width="100%" height="100%" style="overflow:hidden">
                                            </a>
                                            </div>
                                            @endforeach
                                            @endif
                                        </div>
                                    </div>
                                    <!-- <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning btn-round">Edit User</button>
                                        <button type="button" class="btn btn-danger btn-round" data-dismiss="modal">Close</button>
                                    </div> -->
                                </div>
                                </div>
                            </div> 
                            <a href="{{ URL::to('admin/mainsubcategory/'.$sUser->id) }}" class="" title="Edit User" data-toggle="modal" data-target="#myEditModal{{ $sUser->id }}">
                                <i class="fa fa-pencil" aria-hidden="true"></i>
                            </a> &nbsp;
                            <div class="modal" id="myEditModal{{ $sUser->id }}" tabindex="-1" role="dialog">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <form action="{{ route('admin-edit-users') }}" method="post">
                                    @csrf
                                    <input type="text" value="{{ $sUser->id }}" name="id" hidden>
                                    <div class="modal-header">
                                        <h5 class="modal-title">Edit User</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i class="material-icons">clear</i>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group row">
                                            <label>User Role:</label>
                                            <select class="form-control" name="role_id" required>
                                            @if(isset($roles))
                                            @foreach($roles as $role)
                                                <option value="{{ $role->id }}"
                                                @if($sUser->role_id ==$role->id) {{ 'selected' }}@endif>{{ $role->role_name }}</option>
                                            @endforeach
                                            @else
                                                <option value="0">Select Role</option>
                                            @endif
                                        </div>
                                        <div class="form-group row">
                                            <input type="text" class="col-sm-6 form-control" placeholder="Enter First Name" name="first_name" value="{{ $sUser->first_name }}" required>
                                            <input type="text" class="col-sm-6 form-control" placeholder="Enter Last Name" value="{{ $sUser->last_name }}" name="last_name" required>
                                        </div>
                                        <div class="form-group row">
                                            <input type="email" class="col-sm-6 form-control" placeholder="Email" name="email" value="{{ $sUser->email }}" disabled>
                                            <input type="text" class="col-sm-6 form-control" placeholder="Phone" value="{{ $sUser->phone }}" name="phone" required>
                                        </div>
                                        <div class="form-group row">
                                            <input type="date" class="col-sm-6 form-control" placeholder="Birthday" value="{{ $sUser->birthday }}" autocomplete="" name="birthday" required>
                                            <input type="text" class="col-sm-6 form-control" placeholder="Location" value="{{ $sUser->location }}" autocomplete="" name="location" required>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-warning btn-round">Edit User</button>
                                        <button type="button" class="btn btn-danger btn-round" data-dismiss="modal">Close</button>
                                    </div>
                                    </form>
                                </div>
                                </div>
                            </div>
                            <a href="{{ URL::to('admin/mainsubcategory/'.$sUser->id) }}" class="delete_record" msg="Are you sure to delete this job?" title="Delete User">
                                <i class="fa fa-trash" aria-hidden="true"></i>
                            </a>--}}
                        </td>
                    </tr>
                    @php $counter++; @endphp
                    @endforeach
                </tbody>
            </table>
            @if($jobs->links())
                {{ $jobs->links() }}
            @endif
            @endif
        </div>
    </div>
</div>
</div>
@endsection
