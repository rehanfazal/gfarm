<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $table = "question";

    protected function getQuestionOption(){
        return $this->hasMany(QuestionOption::class,'q_id','id');
    }
}
