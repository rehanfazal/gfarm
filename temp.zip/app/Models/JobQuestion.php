<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use App\Models\JobQuestionOption;

class JobQuestion extends Model
{
    protected $table = "job_questions";

    protected function getJob(){
        return $this->hasOne(Job::class,"id","job_id");
    }
    protected function getQuestion(){
        return $this->hasOne(Question::class,"id","q_id");
    }
    public static function getJobQuestionOptions($job_id,$q_id){
        return JobQuestionOption::where("job_id",$job_id)->where("q_id",$q_id)->get();//(JobQuestionOption::class,"q_id","q_id");
    }
}
