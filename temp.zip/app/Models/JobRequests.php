<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobRequests extends Model
{
    protected $table = "job_requests";
}
