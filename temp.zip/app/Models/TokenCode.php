<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TokenCode extends Model
{
    //
    protected $table = 'mobileemailotp';
}
