<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class JobQuestionOption extends Model
{
    protected $table = "jobs_question_options";
    
	protected function getJob(){
        return $this->hasOne(Jobs::class,'id','job_id');
	}
	protected function getQuestionOption(){
        return $this->hasOne(QuestionOption::class,'id','q_option_id');
	}
	protected function getQuestion(){
        return $this->hasOne(Question::class,'id','q_id');
	}
	
}
