<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivitiesQuestionOption extends Model
{
    protected $table = "activities_question_option";

    protected function getActivity(){
        return $this->hasOne(Activities::class,'id','activity_id');
    }
	public function getAllActivity(){
		  return $this->hasMany(Activities::class,'id','activity_id');
	}
}
