<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassificationQuestionOption extends Model
{
    protected $table = "classification_question_option";
    
    protected function getClassification(){
        return $this->hasOne(Classification::class,'id','classification_id');
    }
	public function getAllClassification(){
		return $this->hasMany(Classification::class,'id','classification_id');
	}
}
