<?php



/*

|--------------------------------------------------------------------------

| Web Routes

|--------------------------------------------------------------------------

|

| Here is where you can register web routes for your application. These

| routes are loaded by the RouteServiceProvider within a group which

| contains the "web" middleware group. Now create something great!

|

*/

// Route::get('/','AdminController@dashboard')->name('/');

Route::get('login', 'AdminController@adminLogin')->name('admin-login');

Route::get('logout', 'AdminController@adminLogout')->name('admin-logout');
Route::post('authenticate', 'AdminController@mobilelogin')->name('login-authenticate');


Route::group(['middleware' => ['guest']], function () {
	Route::get('admin/dashboard', 'AdminController@dashboard')->name('admin-dashboard');

	Route::get('admin/services', 'AdminController@listServices')->name('admin-main-services');
	Route::post('admin/add-service', 'AdminController@listServices')->name('admin-main-add-service');

	Route::get('admin/questions', 'AdminController@getServiceQuestions')->name('admin-service-question');
	Route::post('admin/questions', 'AdminController@getServiceQuestions')->name('admin-add-service-question');
	Route::get('admin/question-options', 'AdminController@getSubQuestionOption')->name('admin-main-sub-question-option');
	Route::post('admin/question-options', 'AdminController@getSubQuestionOption')->name('admin-main-sub-question-option-submit');
	Route::get('admin-delete-question','AdminController@deleteSubQuestionOption')->name('admin-delete-question');
	//Route::put('admin/question-options-edit', 'AdminController@editSubQuestionOption')->name('admin-main-sub-question-option-submit-edit');
	Route::post('admin/getquestion', 'AdminController@getMainSubQuestionsList')->name('admin-get-question-cat');
	Route::post('admin/get-question-data','AdminController@getQuestionData')->name('admin-get-question-data');
	Route::get('admin/change-status', 'AdminController@getStatusChanged')->name('admin-change-status');
	Route::post('admin/get-question', 'AdminController@getQuestions')->name('admin-get-question');

	Route::post('admin/editsubcategory/{id}', 'CategoryController@getMainSubCategories')->name('admin-main-sub-categorywe');
	Route::get('admin/deletecategory', 'AdminController@getCatDeleted')->name('admin-delete-sub-category');

	Route::get('admin/users', 'AdminController@userListing')->name('admin-users');
	Route::post('admin/edituser', 'AdminController@editUser')->name('admin-edit-users');
	Route::post('admin/search-users', 'AdminController@userSearch')->name('admin-users-search');


	Route::get('admin/classification', 'AdminController@adminClassification')->name('admin-classification');
	Route::post('admin/add-classification', 'AdminController@adminClassification')->name('admin-add-classification');
	Route::get('admin/classification-status', 'AdminController@adminChangeClassyStatus')->name('admin-classification-status');
	
	
	Route::get('admin/activities', 'AdminController@adminActivities')->name('admin-activities');
	Route::post('admin/add-activities', 'AdminController@adminActivities')->name('admin-add-activities');
	Route::get('admin/activities-status', 'AdminController@adminChangeActivityStatus')->name('admin-activities-status');
	

	/* User Routes 
	Route::get('admin/users', 'AdminController@userListing')->name('users');
	Route::post('admin/users', 'AdminController@userListing')->name('add-user');
	Route::post('admin/changepassword', 'AdminController@changePass')->name('change-password');
	Route::post('admin/activateuser/{id}', 'AdminController@userActivate')->name('user-activate');
	Route::post('admin/deactivateuser/{id}', 'AdminController@userDeactivate')->name('user-deactivate');
	Route::post('admin/deleteuser/{id}', 'AdminController@userDelete')->name('user-delete');*/

	
	/* Jobs Routes */
	Route::get('admin/jobs', 'JobsController@getAllJobs')->name('admin-jobs');
	Route::get('admin/view-job', 'JobsController@viewJob')->name('admin-view-job');
	Route::post('admin/add-jobs', 'JobsController@getAllJobs')->name('admin-add-jobs');
});
