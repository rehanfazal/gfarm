<?php

use Illuminate\Database\Seeder;

class RetailProductOfferedSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
